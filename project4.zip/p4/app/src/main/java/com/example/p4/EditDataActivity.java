package com.example.p4;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;


public class EditDataActivity extends AppCompatActivity {

    private static final String TAG = "EditDataActivity";

    //state buttons
    private Button btnSave;
    private Button btnDelete;
    private Button addReminder;
    private Button setReminder;
    private Button updateBtn;

    //state edit texts
    private EditText inputTime;
    private EditText editName;

    //text views
    private TextView timeTV;
    private TextView textView2;


    DatabaseHelper mDatabaseHelper;//A helper class to manage database creation and version management.

    //values to use in the db
    private String selectedName;
    private int selectedID;
    private int value;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //edit data layout
        setContentView(R.layout.edit_data_layout);

        //defining items.
        ///////////////////////
        //buttons
        btnSave = (Button) findViewById(R.id.btnSave);
        btnDelete = (Button) findViewById(R.id.btnDelete);
        updateBtn=(Button)findViewById(R.id.updateBtn);
        addReminder=(Button)findViewById(R.id.addReminder);
        setReminder=(Button)findViewById(R.id.serReminder);

        //Edit Text
        editName = (EditText) findViewById(R.id.editName);
        inputTime=(EditText) findViewById(R.id.inputTime);

        //text views
        timeTV=(TextView)findViewById(R.id.timeTV);
        textView2=(TextView)findViewById(R.id.textView2);

        mDatabaseHelper = new DatabaseHelper(this);

        //having textsfileds and buttons locked
        editName.setEnabled(false);
        inputTime.setEnabled(false);
        setReminder.setEnabled(false);
        btnSave.setEnabled(false);

        //from ListDataActivity
        Intent receivedIntent = getIntent();

        //itemID as an extra; -1 is default value
        selectedID = receivedIntent.getIntExtra("id",-1);
        selectedName = receivedIntent.getStringExtra("name");

        //set the text to show the current selected name
        textView2.setText(selectedName);
        editName.setText(selectedName);


        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String item = editName.getText().toString();
                if(!item.equals("")){
                    mDatabaseHelper.updateName(item,selectedID,selectedName);
                    backToMain();
                }else{
                    Toast.makeText(EditDataActivity.this, "Enter Data", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mDatabaseHelper.deleteName(selectedID,selectedName);
                editName.setText("");
                //toastMessage();
                //Toast.makeText(this,"Task Deleted.", Toast.LENGTH_SHORT).show();
                Toast.makeText(EditDataActivity.this, "Task Deleted.", Toast.LENGTH_SHORT).show();


                backToMain();;

                //setContentView(R.layout.activity_main);
            }
        });


    }

    //after clicking a button we want the page to fo back to the main page
    private void backToMain()
    {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }


//when the reminder button is clicked, it enables the time and button
    public void reminderButtonClicked(View view)
    {
        int value;
        inputTime.setEnabled(true);
        setReminder.setEnabled(true);
    }

    //when the set reminder button is clicked, takes the input in the field and then passes it to notication.
    public void setReminderBttn(View view)
    {
        value = Integer.parseInt(inputTime.getText().toString()); //the value is the input the user put
        notification(value);
        startTimer();//the timer goes off
    }

    public void notification(int highestNotification)
    {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);


        Intent notificationIntent = new Intent(this, AlarmReceiver.class);
        PendingIntent broadcast = PendingIntent.getBroadcast(this, 100, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        Calendar cal = Calendar.getInstance(); //instance of rela time
        cal.add(Calendar.SECOND, value);
        alarmManager.setExact(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), broadcast);

    }

    private void startTimer()
    {

        new CountDownTimer(value*1000, 1000) {

            public void onTick(long millisUntilFinished) {
                timeTV.setText("Seconds Remaining: " + millisUntilFinished / 1000);
            }

            public void onFinish() {
                timeTV.setText("Done! Check Notifications.");
            }
        }.start();

    }

    public void updateBtnPress(View view)
    {
        editName.setEnabled(true);
        btnSave.setEnabled(true);
    }

}
























